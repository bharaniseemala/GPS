This `docs` folder contains generated pages. 

The source to build and copy these files is in [../assets/generate-pages/](../assets/generate-pages/)