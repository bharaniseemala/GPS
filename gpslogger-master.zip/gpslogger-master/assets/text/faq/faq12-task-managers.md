## What settings are required for task managers?

Task managers don't like GPSLogger and will *frequently* kill the service.  

Due to the varied nature of the way task managers and task killers work, I simply cannot help or advise with any problems where you have one of these installed, and [would advise against it as well](http://www.howtogeek.com/166140/you-dont-need-to-install-a-task-manager-how-to-manage-running-apps-on-android/)


