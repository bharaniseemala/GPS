## Can I use your app in a research project?

This is actually the most commonly asked question!  Yes, feel free to use GPSLogger in your research.  

The source code is [available on Github](https://github.com/mendhak/gpslogger/) if you want to dig through it.  Feel free to link back to the [Github repo](https://github.com/mendhak/gpslogger/) for credit/citation.



  