## How do I download it?

[![qrcode](images/qrcode.gpslogger.png)](market://details?id=com.mendhak.gpslogger)

Search for GPS Logger for Android in Google Play, or follow [this direct link](https://play.google.com/store/apps/details?id=com.mendhak.gpslogger).

You can also download the [APK directly here](https://github.com/mendhak/gpslogger/releases).

