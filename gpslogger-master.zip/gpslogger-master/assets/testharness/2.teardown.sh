#!/bin/bash

docker-compose stop
docker-compose kill
docker-compose rm -f
