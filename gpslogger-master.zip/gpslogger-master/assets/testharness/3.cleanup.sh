#!/bin/bash

rm -rf owncloudstorage/additional_apps
rm -rf owncloudstorage/data
rm -rf ftpstorage
